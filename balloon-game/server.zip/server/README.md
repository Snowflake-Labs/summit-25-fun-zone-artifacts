Start the server with the following command:

```bash
./balloon-popper server -k ./keys/jwt-private-key -p $(cat ./keys/.pass) -c ./config/users.json
```

Open the browser and navigate to `http://localhost:8080` to access the web interface.


## Start the Game

```
./start-game.sh
```


## Stop the Game

```
./start-game.sh
```

## Prerequisites

Ensure the following tools are installed on your machine:

- [Docker Desktop](https://www.docker.com/products/docker-desktop/)
    ```bash
    brew install --cask docker
    ```
- [Python 3.12](https://www.python.org/downloads/release/python-3120/)
    ```bash
    brew install python@3.12
    ```
- [Golang (Go) >= 1.24](https://go.dev/doc/install)
    ```bash
    brew install go
    ```
- [httpie](https://httpie.io/)
    ```bash
    brew install httpie
    ```
- [direnv](https://direnv.net/)
    ```bash
    brew install direnv
    ```
- [dnsmasq](https://formulae.brew.sh/formula/dnsmasq)
    ```bash
    brew install dnsmasq
    ```
- [jq](https://stedolan.github.io/jq/)
    ```bash
    brew install jq
    ```
