#!/usr/bin/env bash

# Load variables from config.json
USERNAME=$(jq -r '.dev.username' config.json)
PASSWORD=$(jq -r '.dev.password' config.json)
PORT=$(jq -r '.dev.port' config.json)
HOST=$(jq -r '.dev.host' config.json)

# First, login to get the token
TOKEN=$(http --form POST "${HOST}:${PORT}/login" \
  username="${USERNAME}" \
  password="${PASSWORD}" \
  Accept:application/json \
  --print=b | jq -r '.token')

# Then use the token to stop the game
http POST "${HOST}:${PORT}/admin/stop" \
  Authorization:"Bearer ${TOKEN}" \
  Content-Type:application/json \
  Accept:application/json
